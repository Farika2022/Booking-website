<?php  
header('Content-Type: application/json');

include("connection.php");
$mysqli = new mysqli('localhost', 'root', '', 'mfa website');
$query = "select count(*)as booking_no, DATE_FORMAT(`date`,'%M')as MonthName from booking group by MonthName";
$result=$mysqli->query($query);
$data=array();

foreach($result as $row){
$data[]=$row;
}

$result->close();
$mysqli->close();

print json_encode($data);
?>  

